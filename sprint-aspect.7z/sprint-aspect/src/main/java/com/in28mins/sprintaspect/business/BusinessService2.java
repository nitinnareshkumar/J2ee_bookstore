/*
 * Put your copyright text here
 */
 package com.in28mins.sprintaspect.business;

import org.springframework.stereotype.Service;

@Service
public class BusinessService2 {
	
	public void execute(){
		System.out.println(" running service 2");
	}

}
