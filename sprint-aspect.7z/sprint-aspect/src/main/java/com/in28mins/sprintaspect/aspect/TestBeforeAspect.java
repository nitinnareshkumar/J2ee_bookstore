/*
 * Put your copyright text here
 */
 package com.in28mins.sprintaspect.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.Configuration;

@Configuration
@Aspect
public class TestBeforeAspect {
	@Before("execution(* com.in28mins.sprintaspect.business.*.*(..))")
	public void beforeBusiness(JoinPoint joinPoint){
		
		System.out.println("intercept business calls for" + joinPoint.getKind() );
	}

}
