/*
 * Put your copyright text here
 */
 package com.in28mins.sprintaspect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.in28mins.sprintaspect.business.BusinessService1;
import com.in28mins.sprintaspect.business.BusinessService2;

@SpringBootApplication
public class SprintAspectApplication implements CommandLineRunner{
	@Autowired
	private BusinessService1 businessService1;
	@Autowired
	private BusinessService2 businessService2;
	public static void main(String[] args) {
		ApplicationContext appContext = SpringApplication.run(SprintAspectApplication.class, args);
		
	}
	@Override
	public void run(String... arg0) throws Exception {
		businessService1.execute();
		businessService2.execute();
		
	}
}
