/*
 * Put your copyright text here
 */
 package com.in28mins.springbootrest;

public class Book {
	
	public int id;
	public String name;
	public Book(int id, String name) {
		
		this.id = id;
		this.name = name;
	}

}
