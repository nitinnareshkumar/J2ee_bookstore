/*
 * Put your copyright text here
 */
 package com.in28mins.springbootrest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class BookRestController {
	
	@GetMapping("/books")
	public List<Book> getBooks(){
		ArrayList<Book> books = new ArrayList<Book>();
		books.add(new Book(1, "Peter"));
		books.add(new Book(2, "lunch"));
		return books;
		
		
	}

}
