package com.in28minutes.spring.basics.springin5mins;

import org.springframework.stereotype.Component;

@Component
public class PrinterBean {
	public static void testPrint(){
		System.out.println("i am in printer bean");
	}

}
