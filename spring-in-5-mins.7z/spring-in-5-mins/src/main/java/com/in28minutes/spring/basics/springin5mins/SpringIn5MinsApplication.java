/*
 * Put your copyright text here
 */
 package com.in28minutes.spring.basics.springin5mins;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringIn5MinsApplication {
	@Autowired
	static PrinterBean printerBean;
	public static void main(String[] args) {
		ApplicationContext appContext = SpringApplication.run(SpringIn5MinsApplication.class, args);
		printerBean.testPrint();
		PrinterBean p2 = appContext.getBean(PrinterBean.class);
		p2.testPrint();
	}
	public static PrinterBean getPrinterBean() {
		return printerBean;
	}
	public static void setPrinterBean(PrinterBean printerBean) {
		SpringIn5MinsApplication.printerBean = printerBean;
	}
	
	public int sum (int a , int b){
		return a+b;
	}
	
}
