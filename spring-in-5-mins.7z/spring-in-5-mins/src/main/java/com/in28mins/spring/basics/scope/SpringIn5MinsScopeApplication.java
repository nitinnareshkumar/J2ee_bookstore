/*
 * Put your copyright text here
 */
 package com.in28mins.spring.basics.scope;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringIn5MinsScopeApplication {
	private static Logger LOGGER = 
			LoggerFactory.getLogger(SpringIn5MinsScopeApplication.class); 
	
	public static void main(String[] args) {

		ApplicationContext applicationContext = 
				SpringApplication.run(SpringIn5MinsScopeApplication.class, args);
		
		PersonDao personDao = 
				applicationContext.getBean(PersonDao.class);
		
		PersonDao personDao2 = 
				applicationContext.getBean(PersonDao.class);
		System.out.println("in main");
		LOGGER.info("================");
		LOGGER.info("{}", personDao);
		LOGGER.info("{}", personDao.getJdbcConnection());
		
		LOGGER.info("{}", personDao2);
		LOGGER.info("{}", personDao.getJdbcConnection());
		
		LOGGER.info("{}", personDao2);
		LOGGER.info("{}", personDao.getJdbcConnection());
		LOGGER.info("{}", personDao.getJdbcConnection());
		LOGGER.info("================");
		
		PersonDao personDao3 = new PersonDao();
		LOGGER.info("{}", personDao3);
		LOGGER.info("{}", personDao3.getJdbcConnection());
		LOGGER.info("{}", personDao3.getJdbcConnection());
	}
	public int sum (int a , int b){
		return a+b;
	}
	
}
