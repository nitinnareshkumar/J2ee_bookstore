/*
 * Put your copyright text here
 */
 package com.in28mins.spring.basics.scope;

import org.junit.Test;

import junit.framework.Assert;

public class SpringIn5MinsScopeApplicationTest {

	@Test
	public void testMain() {
		System.out.println("in junit");
		SpringIn5MinsScopeApplication.main(new String[]{"wer","weree"});
		
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testSum() {
		SpringIn5MinsScopeApplication sc = new SpringIn5MinsScopeApplication();
		Assert.assertEquals(7, 	sc.sum(2, 4));
		
	}

}
